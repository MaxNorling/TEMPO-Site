
package tempo;

import java.awt.image.*;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author Oscar Almqvist
 */
public class Spritesheet {
    BufferedImage sheet = null;
    
    public Spritesheet() {
        try {
            sheet = ImageIO.read(new File("src/resources/pics/sheet.png"));
        } catch(Exception e) {}
    }
    
    public BufferedImage getSprite(int row, int column, int height, int width) {
        int a = 32;
        try {
            return sheet.getSubimage(row*a, column*a, height*a, width*a);
        } catch(Exception e) {
            return sheet.getSubimage(0,0,a,a);
        }
    }
    
    public BufferedImage getImage(String content) {
        BufferedImage tempImage = null;
        try {
            tempImage = ImageIO.read(new File(content));
        } catch(Exception e) {
            System.out.println(content + "-filen kunde inte hittas");
        }
        return tempImage;
    }
}
