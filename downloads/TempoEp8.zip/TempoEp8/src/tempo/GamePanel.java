
package tempo;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.JPanel;
import tempo.sprite.Block;
import tempo.sprite.Player;

/**
 *
 * @author Oscar Almqvist
 */
public class GamePanel extends JPanel {
    
    public static final int BLOCK_SIZE = 75;
    public ArrayList<Block> blocks = new ArrayList<Block>();
    public ArrayList<Background> backgrounds = new ArrayList<Background>();
    
    private Spritesheet ss = new Spritesheet();
    private Player player = new Player(200, 200, BLOCK_SIZE, BLOCK_SIZE * 2, ss.getSprite(1, 5, 1, 2), 10, 0, 10);
    
    
    
    public GamePanel(){
        int x = 0;
        int y = 400;
        for(int i = 0;i<20;i++){
            blocks.add(new Block(x*75,y,75,75,ss.getSprite(0, 0, 1, 1), true));
            x++;
        }
        player.createAnimation();
        player.getAnimation().setAnimation(/*Running (0-5)*/ getPS(0,3), getPS(1,3), getPS(2,3), getPS(3,3), getPS(4,3), getPS(5,3), /*Idle (6-8)*/ getPS(0,5), getPS(1,5), getPS(2,5) /*Jumping (9)*/, getPS(3,5), /*Falling (10)*/ getPS(4,5));
        backgrounds.add(new Background(0f, 0, 0, 1280, 720, ss.getImage("src/resources/pics/clouds.png"),player));
        backgrounds.add(new Background(0.1f, 0, 500, 1280, 720, ss.getImage("src/resources/pics/mountains_final1.png"),player));
        
    }
    
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        for(Background b: backgrounds){
            if(b.getVelocityX() > 0){
                g2.translate(0, -(float)player.getRectangle().y+(460-75) * b.getVelocityX() - (float)b.getRectangle().height*b.getVelocityX()*0.5);
            }
            b.paint(g2);
            resetTranslate(g2);
            
        }
        g2.translate(-player.getRectangle().x + (640-32), -player.getRectangle().y + (460 -75));
            
        player.paint(g);
        for(Block b: blocks){
            b.paint(g2);
        }
        
    }
    public void resetTranslate(Graphics2D g2){
        Rectangle r = g2.getClipBounds();
        g2.translate(r.x,r.y);
    }
    public Player getPlayer(){
        return player;
    }
    public BufferedImage getPS(int x, int y) {
        return ss.getSprite(x, y, 1, 2);
    }

}
