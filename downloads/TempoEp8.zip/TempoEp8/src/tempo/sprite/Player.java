
package tempo.sprite;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Oscar Almqvist
 */
public class Player extends Sprite {
    private boolean movingLeft, movingRight, canJump, jumping, falling, flipped;
    private Animation animation;
 
    
    public Player(int x, int y, int width, int height,  BufferedImage image, float dx, float dy, float gravity) {
        super(x, y, width, height, image, dx, dy, gravity);
    }

    @Override
    public void paint(Graphics g) {
        Rectangle r = super.getRectangle();
        if (flipped) {
            g.drawImage(super.getImage(), r.x + r.width, r.y, -r.width, r.height, null);
        } else {
            g.drawImage(super.getImage(), r.x, r.y, r.width, r.height, null);
        }
    }

    public void tick(){
        getRectangle().y += getVelocityY();
        setVelocityY(getVelocityY()+ getGravity());
        
        if(movingLeft){
            getRectangle().x -=getVelocityX();
        }
        if(movingRight){
            getRectangle().x +=getVelocityX();
            
        }
        
        jumping = super.getVelocityY() < 0;
        
        falling = super.getVelocityY() > 0;
        
        animation.tick();
    }
    public void setMovingLeft(boolean b){
        movingLeft = b;
    }
    public void setMovingRight(boolean b){
        movingRight = b;
    }
    public boolean getMovingLeft() {
        return movingLeft;
    }
    public boolean getMovingRight() {
        return movingRight;
    }
    public boolean getJumping() {
        return jumping;
    }
    public boolean getFalling() {
        return falling;
    }
    public boolean getCanJump(){
        return canJump;
    }
    public void setCanJump(boolean b){
        canJump = b;
    }
    public void createAnimation() {
        animation = new Animation(this);
    }
    public Animation getAnimation() {
        return animation;
    }
    public void setFlipped(boolean flipped) {
        this.flipped = flipped;
    }
}
