package tempo;

import tempo.sprite.Block;

/**
 *
 * @author Oscar Almqvist
 */
public class GameEngine implements Runnable{
    int prevX;
    
    
    GamePanel gp;
    Collision collision = new Collision();
    private boolean running = false;
    
    public GameEngine(GamePanel gp) {
        this.gp = gp;
        start();
    }
    
    public void start(){
        running = true;
        new Thread(this).start();
    }
    
    public void run(){
        long lastTime = System.nanoTime();
        double nsPerTick = 1000000000D/60D;
        
        double delta = 0;
        
        while(running){
            long now = System.nanoTime();
            delta += (now - lastTime) / nsPerTick;
            lastTime = now;
            
            try{
                Thread.sleep(16);
            } catch (InterruptedException e){
                e.printStackTrace();
            }
            
            while(delta >= 1){
                tick();
                render();
                delta -= 1;
            }
        }
    }
    
    public void tick(){
        gp.getPlayer().tick();
        checkCollision();
        moveBackground();
    }
    
    public void render(){
        gp.repaint();
    }
    public void checkCollision(){
        for(Block b : gp.blocks){
            if(b.coll){
                if(collision.getTopCollision(gp.getPlayer().getRectangle(), b.getRectangle()) && gp.getPlayer().getVelocityY() > 0){
                    //KOLLIDERA MED MARK
                    gp.getPlayer().setGravity(0);
                    gp.getPlayer().setVelocityY(0);
                    gp.getPlayer().setCanJump(true);
                }
                else{
                    gp.getPlayer().setGravity(2f);
                }

                if(collision.getBottomCollision(gp.getPlayer().getRectangle(), b.getRectangle())){
                    //KOLLIDERA MED TAK
                }
                gp.getPlayer().setRectangle(collision.getCollision(gp.getPlayer().getRectangle(), b.getRectangle()));
            }
        }
    }
    public void moveBackground(){
        if(gp.getPlayer().getRectangle().x < prevX){
            for(Background b: gp.backgrounds){
                b.moveLeft();
            }
        }
        if(gp.getPlayer().getRectangle().x > prevX){
            for(Background b: gp.backgrounds){
                b.moveRight();
            }
        }
        prevX = gp.getPlayer().getRectangle().x;
    }
}
