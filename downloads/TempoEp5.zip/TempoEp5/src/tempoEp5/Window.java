
package tempo;

import javax.swing.JFrame;

/**
 *
 * @author Oscar Almqvist
 */
public class Window extends JFrame {
    
    private GamePanel gp;
    private GameEngine ge;
    
    public Window() {
        gp = new GamePanel();
        ge = new GameEngine(gp);
        setTitle(Tempo.NAME);
        setSize(Tempo.WIDTH, Tempo.HEIGHT);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(gp);
        
    }

}
