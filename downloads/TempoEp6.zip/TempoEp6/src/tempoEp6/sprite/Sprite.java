
package tempo.sprite;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Oscar Almqvist
 */
public abstract class Sprite {

    private Rectangle rect;
    private BufferedImage image;
    private float dx, dy, gravity;
    
    public Sprite(int x, int y, int width, int height, BufferedImage image, float dx, float dy, float gravity) {
        this.rect = new Rectangle(x, y, width, height);
        this.image = image;
        this.dx = dx;
        this.dy = dy;
        this.gravity = gravity;
    }
    
    
    public abstract void paint(Graphics g);
    
    public BufferedImage getImage() {
        return image;
    }
    
    public Rectangle getRectangle() {
        return rect;
    }
    public void setRectangle(Rectangle rectangle) {
        this.rect = rectangle;
    }
    public float getVelocityX(){
        return dx;
    }
    public void setVelocityY(float f){
        this.dy = f;
    }
    public float getVelocityY(){
        return dy;
    }
    public float getGravity(){
        return gravity;
    }
    public void setGravity(float f ){
        gravity = f;
    }
}
