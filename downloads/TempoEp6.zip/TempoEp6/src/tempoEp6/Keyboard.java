/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tempo;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author Elev
 */
public class Keyboard implements KeyListener {
    private GamePanel gp;
       public Keyboard(GamePanel gp){
           this.gp = gp;
       }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_D: gp.getPlayer().setMovingRight(true);break;
            case KeyEvent.VK_A: gp.getPlayer().setMovingLeft(true); break;
            case KeyEvent.VK_SPACE:
                if(gp.getPlayer().getCanJump()){
                    gp.getPlayer().setVelocityY(-23f);
                    gp.getPlayer().setCanJump(false);
                }
            break;
      
        } 
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_D: gp.getPlayer().setMovingRight(false); break;
            case KeyEvent.VK_A: gp.getPlayer().setMovingLeft(false); break;
        }
    }
    
}
