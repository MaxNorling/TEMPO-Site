/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tempo.sprite;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;
import tempo.Spritesheet;

/**
 *
 * @author Elev
 */
public class Level {
    private Spritesheet ss;
    private ArrayList<Block> level = new ArrayList<Block>();
    private int blockSize;
    
    public Level(Spritesheet ss, String level,int blockSize){
        this.ss = ss;
        this.blockSize = blockSize;
        int row = 0;
        
        try {
            BufferedReader br = new BufferedReader(new FileReader(level));
                String line;
                
                while((line = br.readLine())!= null){
                    String tempStr = line;
                    
                    for(int j =0; j < tempStr.length(); j++){
                        char chr = tempStr.charAt(j);
                        switch(chr){
                            case 'd': addBlock(true, j, row,1,1,1,0); break;
                            case '-': break;
                        }
                        if(j == tempStr.length()-1 ){
                           row++; 
                        }
                    }
                }
            
        } catch (IOException ex) {
            Logger.getLogger(Level.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }
    
    public void addBlock(boolean coll, int x, int y, int width, int height, int imgX ,int imgY ){
        level.add(new Block(x*blockSize,y*blockSize,width*blockSize,height*blockSize, ss.getSprite(imgX,imgY,width,height),coll));
    }
    public ArrayList<Block> getLevel(){
        return level;
    }
    
}
