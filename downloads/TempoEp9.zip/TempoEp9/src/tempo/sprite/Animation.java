/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tempo.sprite;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Animation {
    
    private Player player;
    private ArrayList<BufferedImage> images;
    private int ticks = 0;
    private int interval = 6;
    private int currentImage, startImage, endImage;
    
    public Animation(Player player) {
        this.player = player;
        images = new ArrayList<BufferedImage>();
    }
    
    public void setAnimation(BufferedImage ... images) {
        currentImage = 0;
        this.images.clear();
        
        for(BufferedImage image : images) {
            this.images.add(image);
        }
        
        player.setImage(this.images.get(currentImage));
    }
    
    public void tick() {
        
        if (++ticks >= interval) {
            if (currentImage > endImage || currentImage <= startImage) {
                currentImage = startImage;
            }
            
            player.setImage(images.get(currentImage));
            currentImage++;
            
            ticks = 0;
        }
        
        setImages(0,5);
        
        if (!player.getMovingLeft() && !player.getMovingRight()) {
            setImages(6,8);
        }
        
        if (!player.getCanJump()) {
            if (player.getJumping()) {
                setImages(9,9);
            }
            if (player.getFalling()) {
                setImages(10,10);
            }
        }
    }
    
    public void setImages(int start, int end) {
        startImage = start;
        endImage = end;
    }
}
