/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tempo;

import java.awt.Rectangle;

/**
 *
 * @author Elev
 */
public class Collision {
    public boolean isIntersect(Rectangle a_rect, Rectangle o_rect){
        return a_rect.intersects(o_rect);
    }
    public double collisionRotation(Rectangle a_rect, Rectangle o_rect){
        return Math.toDegrees(Math.atan2(o_rect.x-a_rect.x,o_rect.y-a_rect.y));
    }
    public Rectangle getCollision(Rectangle a_rect, Rectangle o_rect){
        Rectangle tempRect = new Rectangle();
        if(isIntersect(a_rect,o_rect)){
            //Right Side
            if(collisionRotation(a_rect,o_rect) > -140f && collisionRotation(a_rect,o_rect) < -26f ){
                tempRect = a_rect;
                tempRect.x = o_rect.x + o_rect.width;
                return tempRect;
            }
            //Left Side
            if(collisionRotation(a_rect,o_rect) < 140f && collisionRotation(a_rect,o_rect) > 26f ){
                tempRect = a_rect;
                tempRect.x = o_rect.x - a_rect.width;
                return tempRect;
            }
            //Top Side
            if(collisionRotation(a_rect,o_rect) > -26f && collisionRotation(a_rect,o_rect) < 26f ){
                tempRect = a_rect;
                tempRect.y = o_rect.y - a_rect.height;
                return tempRect;
            }
            //Bottom Side
            if(collisionRotation(a_rect,o_rect) < 140f && collisionRotation(a_rect,o_rect) > 140f ){
                tempRect = a_rect;
                tempRect.y = o_rect.y + a_rect.height;
                return tempRect;
            }
        }
        return a_rect;
    }
    public boolean getTopCollision(Rectangle a_rect, Rectangle o_rect){
        if(isIntersect(a_rect,o_rect)){
            if(collisionRotation(a_rect,o_rect) > -26f && collisionRotation(a_rect,o_rect) < 26f ){
                return true;
            }
        }
        return false;
    }
    public boolean getBottomCollision(Rectangle a_rect, Rectangle o_rect){
        if(isIntersect(a_rect,o_rect)){
            if(collisionRotation(a_rect,o_rect) > 26f && collisionRotation(a_rect,o_rect) < 26f ){
                return true;
            }
        }
        return false;
    }
}
