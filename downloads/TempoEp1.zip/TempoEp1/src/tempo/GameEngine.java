
package tempo;

/**
 *
 * @author Oscar Almqvist
 */
public class GameEngine {
    
    GamePanel gp;
    
    public GameEngine(GamePanel gp) {
        this.gp = gp;
    }

}
