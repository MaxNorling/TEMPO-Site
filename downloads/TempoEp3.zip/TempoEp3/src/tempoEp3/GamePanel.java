
package tempo;

import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;
import tempo.sprite.Player;

/**
 *
 * @author Oscar Almqvist
 */
public class GamePanel extends JPanel {
    
    public static final int BLOCK_SIZE = 75;
    
    private Spritesheet ss = new Spritesheet();
    private Player player = new Player(200, 200, BLOCK_SIZE, BLOCK_SIZE * 2, ss.getSprite(1, 5, 1, 2), 0, 0, 10);
    
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        player.paint(g);
    }

}
