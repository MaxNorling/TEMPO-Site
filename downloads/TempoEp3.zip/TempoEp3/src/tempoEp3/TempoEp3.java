
package tempo;

/**
 *
 * @author Oscar Almqvist
 */
public class TempoEp3 {

    public static final String NAME = "Tempo";
    public static final int WIDTH = 1280;
    public static final int HEIGHT = 768;
    
    public TempoEp3() {
        new Window();
    }
    
    public static void main(String[] args) {
        new TempoEp3();
    }
}
