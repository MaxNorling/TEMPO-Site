
package tempo_tutorial;

public class Tempo_tutorial {

    public static String NAME = "Tempo";
    public static int WIDTH = 1280;
    public static int HEIGHT = 768;
    
    public Tempo_tutorial() {
        new Window();
    }
    
    public static void main(String[] args) {
        new Tempo_tutorial();
    }
}
