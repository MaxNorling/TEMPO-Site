
package tempo_tutorial;

public class Tempo {

    public static String NAME = "Tempo";
    public static int WIDTH = 1280;
    public static int HEIGHT = 768;
    
    public Tempo() {
        new Window();
    }
    
    public static void main(String[] args) {
        new Tempo();
    }
}
