package tempo;

/**
 *
 * @author Oscar Almqvist
 */
public class GameEngine implements Runnable{
    
    GamePanel gp;
    private boolean running = false;
    
    public GameEngine(GamePanel gp) {
        this.gp = gp;
        start();
    }
    
    public void start(){
        running = true;
        new Thread(this).start();
    }
    
    public void run(){
        long lastTime = System.nanoTime();
        double nsPerTick = 1000000000D/60D;
        
        double delta = 0;
        
        while(running){
            long now = System.nanoTime();
            delta += (now - lastTime) / nsPerTick;
            lastTime = now;
            
            try{
                Thread.sleep(16);
            } catch (InterruptedException e){
                e.printStackTrace();
            }
            
            while(delta >= 1){
                tick();
                render();
                delta -= 1;
            }
        }
    }
    
    public void tick(){
        gp.getPlayer().getRectangle().x++;
    }
    
    public void render(){
        gp.repaint();
    }
}
